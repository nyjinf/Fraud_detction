from django.urls import path
from .views import home, predict_fraud

urlpatterns = [
    path('', home, name='home'),  # Home page
    path('predict/', predict_fraud, name='predict_fraud'),  # Form submission and prediction
]
