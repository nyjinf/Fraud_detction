from django.shortcuts import render
import joblib
from keras.models import load_model
import numpy as np
from sklearn.preprocessing import StandardScaler
import os


# Load the model and scaler
MODEL_PATH = 'detection/ml_models/credit_card_model.h5'
SCALER_PATH = 'detection/ml_models/creditcard_scaler.pkl'
model = load_model(MODEL_PATH)
scaler = joblib.load(SCALER_PATH)

# Home view
def home(request):
    return render(request, 'detection/home.html')

# Predict fraud view
def predict_fraud(request):
    if request.method == 'POST':
        # Extract the features from the POST data
        features = [
            float(request.POST.get('Time')),
            float(request.POST.get('V1')),
            float(request.POST.get('V2')),
            float(request.POST.get('V3')),
            float(request.POST.get('V4')),
            float(request.POST.get('V5')),
            float(request.POST.get('V6')),
            float(request.POST.get('V7')),
            float(request.POST.get('V8')),
            float(request.POST.get('V9')),
            float(request.POST.get('V10')),
            float(request.POST.get('V11')),
            float(request.POST.get('V12')),
            float(request.POST.get('V13')),
            float(request.POST.get('V14')),
            float(request.POST.get('V15')),
            float(request.POST.get('V16')),
            float(request.POST.get('V17')),
            float(request.POST.get('V18')),
            float(request.POST.get('V19')),
            float(request.POST.get('V20')),
            float(request.POST.get('V21')),
            float(request.POST.get('V22')),
            float(request.POST.get('V23')),
            float(request.POST.get('V24')),
            float(request.POST.get('V25')),
            float(request.POST.get('V26')),
            float(request.POST.get('V27')),
            float(request.POST.get('V28')),
            float(request.POST.get('Amount'))
        ]

        # Rescale the features using the loaded scaler
        features_scaled = scaler.transform([features])

        # Make a prediction using the model
        prediction = model.predict(features_scaled)[0]

        # Format the prediction
        prediction_result = "Fraudulent" if prediction == 1 else "Not Fraudulent"

        return render(request, 'detection/results.html', {'prediction': prediction_result})
    
    return render(request, 'detection/form.html')
